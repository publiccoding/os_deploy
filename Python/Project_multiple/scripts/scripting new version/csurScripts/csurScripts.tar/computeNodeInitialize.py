import logging
import os
import subprocess
import re
from fusionIOUtils import checkFusionIOFirmwareUpgradeSupport


class ComputeNodeInitialize():
	def __init__(self, csurResourceDict):
		self.csurResourceDict = csurResourceDict

		try:
			csurBasePath = self.csurResourceDict['csurBasePath']
                        logLevel = self.csurResourceDict['logLevel']
		except KeyError as err:
			raise KeyError(str(err))

		logBaseDir = csurBasePath + '/log'

                try:
                        self.computeNodeName = os.uname()[1]
                except OSError as err:
			raise OSError(str(err))

                computeNodeLog = logBaseDir + '/computeNode_' + self.computeNodeName + '.log'

                #Configure logging
                handler = logging.FileHandler(computeNodeLog)

                logger = logging.getLogger(self.computeNodeName)

                if logLevel == 'debug':
                        logger.setLevel(logging.DEBUG)
                else:
                        logger.setLevel(logging.INFO)

                formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(message)s', datefmt='%m/%d/%Y %H:%M:%S')
                handler.setFormatter(formatter)
                logger.addHandler(handler)

	#End __init__(self, csurResourceDict):


	'''
	This function is used to initialize for a compute node update.
	'''
	def computeNodeInitialize(self): 
		logger = logging.getLogger(self.computeNodeName)

                computeNodeDict = {'errorMessage' : '', 'computeNodeName' : self.computeNodeName}

                #Get system model.
                command = "dmidecode -s system-product-name"
                result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
                out, err = result.communicate()

                logger.debug("The output of the command (" + command + ") used to get the system's model was: " + out.strip())

                if result.returncode != 0:
                        logger.error("Unable to get the system's model information.\n" + err)
                        computeNodeDict['errorMessage'] = "Error: Unable to get the system's model information."
                        return computeNodeDict

		try:
                	systemModel = (re.match('[a-z,0-9]+\s+(.*)', out, re.IGNORECASE).group(1)).replace(' ', '')
		except AttributeError as err:
			computeNodeDict['errorMessage'] = "Error: system model match error: " + str(err) + "."
			return computeNodeDict

                try:
			if systemModel not in self.csurResourceDict['supportedComputeNodeModels']:
				logger.error("The system's model (" + systemModel + ") is not supported by this CSUR bundle.")
                                logger.info("The supported supported models are (" + self.csurResourceDict['supportedComputeNodeModels'] + ").")
                                computeNodeDict['errorMessage'] = "Error: The system's model is not supported by this CSUR bundle."
                                return computeNodeDict
                except KeyError as err:
                        logger.error("The resource key (" + str(err) + ") was not present in the resource file.")
                        computeNodeDict['errorMessage'] = "Error: A resource key error was encountered."
                        return computeNodeDict

                logger.debug("The system's model was determined to be: " + systemModel + ".")

                computeNodeDict['systemModel'] = systemModel

		#On NFS servers we want to check and notify if the cluster is still running.
		if 'DL380' in systemModel:
			command = '/opt/cmcluster/bin/cmviewcl -f line'
			result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
			out, err = result.communicate()

			logger.debug("The output of the command (" + command + ") used to check if the cluster is running was: " + out.strip())

			if result.returncode != 0:
				logger.warn("Unable to check if the cluster is running.\n" + err)
                                computeNodeDict['errorMessage'] = "Warn: Unable to check if the cluster is running."

			clusterView = out.splitlines()

			for line in clusterView:
				if re.search('^status=', line):
					if re.match('status=up', line):
						logger.warn("It appears that the cluster is still running.\n" + out)
						computeNodeDict['errorMessage'] = "Warn: It appears that the cluster is still running."

		'''
		On servers that are not Serviceguard we check if SAP HANA is running and notif if it is running.
		We can assume that processes are not running is we get a return code of 1.
		'''
		if not ('DL380' in systemModel or 'DL320' in systemModel):
			command = 'ps -C hdbnameserver,hdbcompileserver,hdbindexserver,hdbpreprocessor,hdbxsengine,hdbwebdispatcher'
			result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
			out, err = result.communicate()

			logger.debug("The output of the command (" + command + ") used to check if SAP is running was: " + out.strip())

			if result.returncode == 0:
				logger.warn("It appears that SAP HANA is still running.\n" + out)
				computeNodeDict['errorMessage'] = "Warn: It appears that SAP HANA is still running."
		
		#Get the system's OS distribution version information.
		command = "cat /proc/version"
		result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
		out, err = result.communicate()

		logger.debug("The output of the command (" + command + ") used to get the OS distribution information was: " + out.strip())

		#Change version information to lowercase before checking for OS type.
		versionInfo = out.lower()
		
		if result.returncode != 0:
			logger.error("Unable to get the system's OS distribution version information.\n" + err)
                        computeNodeDict['errorMessage'] = "Error: Unable to get the system's OS distribution version information."
                        return computeNodeDict

		if 'suse' in versionInfo:
			OSDist = 'SLES'
			command = "cat /etc/SuSE-release"
		else:
			OSDist = 'RHEL'
			command = "cat /etc/redhat-release"

		result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
		out, err = result.communicate()

		if result.returncode != 0:
			logger.error("Unable to get the system's OS distribution level.\n" + err)
                        computeNodeDict['errorMessage'] = "Unable to get the system's OS distribution level."
                        return computeNodeDict
		else:
			releaseInfo = out.replace('\n', ' ')

			if OSDist == 'SLES':
				try:
					slesVersion = re.match('.*version\s*=\s*([1-4]{2})', releaseInfo, re.IGNORECASE).group(1)
				except AttributeError as err:
					computeNodeDict['errorMessage'] = "Error: SLES OS version match error: " + str(err) + "."
					return computeNodeDict

				try:
					slesPatchLevel = re.match('.*patchlevel\s*=\s*([1-4]{1})', releaseInfo, re.IGNORECASE).group(1)
				except AttributeError as err:
					computeNodeDict['errorMessage'] = "Error: SLES patch level match error: " + str(err) + "."
					return computeNodeDict

				osDistLevel = OSDist + slesVersion + '.' + slesPatchLevel
			else:
				try:
					rhelVersion = re.match('.*release\s+([6-7]{1}.[0-9]{1}).*', releaseInfo, re.IGNORECASE).group(1)
				except AttributeError as err:
					computeNodeDict['errorMessage'] = "Error: RHEL OS version match error: " + str(err) + "."
					return computeNodeDict

				osDistLevel = OSDist + rhelVersion

		try:
			if osDistLevel not in self.csurResourceDict['supportedDistributionLevels']:
				logger.error("The system's OS distribution level (" + osDistLevel + ") is not supported by this CSUR bundle.")
				logger.info("The supported OS distribution levels are (" + self.csurResourceDict['supportedDistributionLevels'] + ").")
                                computeNodeDict['errorMessage'] = "Error: The system's OS distribution level is not supported by this CSUR bundle."
                                return computeNodeDict
                except KeyError as err:
                        logger.error("The resource key (" + str(err) + ") was not present in the resource file.")
                        computeNodeDict['errorMessage'] = "Error: A resource key error was encountered."
                        return computeNodeDict

		computeNodeDict['osDistLevel'] = osDistLevel

		logger.debug("The system's OS distribution level was determined to be: " + osDistLevel + ".")

		'''
		Additional kernel version and processorType is needed for FusionIO systems when the driver is rebuilt.	
		Also, need to confirm the system is already at a supported firmware version for automatic upgrades.
		'''
		if systemModel == 'DL580G7' or systemModel == 'DL980G7':
			#Check if /hana/log or /HANA/IMDB-log is mounted.
			command = 'mount'
			result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
			out, err = result.communicate()

			logger.debug("The output of the command (" + command + ") used to check if the log partition is mounted was: " + out.strip())

			if result.returncode != 0:
				logger.error("Unable to check if the log partition is mounted.\n" + err)
                                computeNodeDict['errorMessage'] = "Error: Unable to check if the log partition is mounted."
                                return computeNodeDict

			if re.search('/hana/log|/HANA/IMDB-log', out, re.MULTILINE|re.DOTALL) != None:
				logger.error("The log partition is still mounted.")
                                computeNodeDict['errorMessage'] = "Error: The log partition needs to be unmounted before the system is updated."
                                return computeNodeDict

			#Get the currently used kernel and processor type, which is used as part of the FusionIO driver RPM name.
			command = 'uname -r'
			result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
			out, err = result.communicate()

			logger.debug("The output of the command (" + command + ") used to get the currently used kernel was: " + out.strip())

			if result.returncode != 0:
				logger.error("Unable to get the system's current kernel information.\n" + err)
                                computeNodeDict['errorMessage'] = "Error: Unable to get the system's current kernel information."
                                return computeNodeDict
			else:
				kernel = out.strip()
				computeNodeDict['kernel'] = kernel
			
			command = 'uname -p'
			result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
			out, err = result.communicate()

			logger.debug("The output of the command (" + command + ") used to get the system's processor type was: " + out.strip())

			if result.returncode != 0:
				logger.error("Unable to get the system's processor type.\n" + err)
                                computeNodeDict['errorMessage'] = "Error: Unable to get the system's processor type."
                                return computeNodeDict
			else:
				processorType = out.strip()
				computeNodeDict['processorType'] = processorType

			try:
				if not checkFusionIOFirmwareUpgradeSupport(csurResourceDict['fusionIOFirmwareVersionList'], self.computeNodeName):
					computeNodeDict['errorMessage'] = "Error: The fusionIO firmware is not at a supported version for an automatic upgrade."
					return computeNodeDict
			except KeyError as err:
				logger.error("The resource key (" + str(err) + ") was not present in the resource file.")
				computeNodeDict['errorMessage'] = "Error: A resource key error was encountered."
				return computeNodeDict

		#Confirm that the drivers for the system being updated are loaded.
		result = self.__checkDrivers(computeNodeDict.copy())

		if result != '':
			computeNodeDict['errorMessage'] = result

		return computeNodeDict

	#End computeNodeInitialize(self): 


	'''
	This function is used to confirm that the drivers to be checked for an update are loaded.
	'''
	def __checkDrivers(self, computeNodeDict):
		csurData = self.csurResourceDict['csurData']
		osDistLevel = computeNodeDict['osDistLevel']
		systemModel = computeNodeDict['systemModel']

		errorMessage = ''

		logger = logging.getLogger(self.computeNodeName)

		driversFound = False
		started = False

		#Need to check twice for the Mellonex driver, since it can have two different names (mlx4_en or mlnx).
		mlnxDriverFound = False

                for data in csurData:
                        #Remove spaces if any are present.
                        data = data.replace(' ', '')

                        if not 'Drivers' in data and not driversFound:
                                continue
                        elif 'Drivers' in data:
                                driversFound = True
                                continue
                        elif not ((osDistLevel in data) and (systemModel in data)) and not started:
                                continue
                        elif (osDistLevel in data) and (systemModel in data):
                                started = True
                                continue
                        elif re.match(r'\s*$', data):
                                break
                        else:
                                csurDriverList = data.split('|')
                                csurDriver = csurDriverList[0]

                                command = "modinfo " + csurDriver
                                result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
                                out, err = result.communicate()

                                logger.debug("The output of the command (" + command + ") used to check if the " + csurDriver + " driver is loaded was: " + out.strip())

                                if result.returncode != 0:
					if (csurDriver == 'mlx4_en' or csurDriver == 'mlnx') and not mlnxDriverFound:
						mlnxDriverFound = True
						continue
					logger.error("The " + csurDriver + " driver does not appear to be loaded.\n" + err)
					errorMesssage = "Error: The " + csurDriver + " driver does not appear to be loaded."

		if (systemModel == 'DL580G7' or systemModel == 'DL980G7') and errorMessage == '':
			command = "modinfo iomemory_vsl"
			result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
			out, err = result.communicate()

			logger.debug("The output of the command (" + command + ") used to check if the iomemory_vsl driver is loaded was: " + out.strip())

			if result.returncode != 0:
				logger.error("The iomemory_vsl driver does not appear to be loaded.\n" + err)
				errorMesssage = "Error: The iomemory_vsl driver does not appear to be loaded."

		return errorMessage

	#End __checkDrivers(self, computeNodeDict):

#End class ComputeNodeInitialize():
