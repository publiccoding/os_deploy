#!/usr/bin/python

import re
import signal
import time
from threading import Thread
from modules.computeNodeInventory import (ComputeNode, Gen1ScaleUpComputeNode)
from modules.csurUpdateUtils import (RED, GREEN, YELLOW, PURPLE, UNDERLINE, RESETCOLORS, SignalHandler)
from modules.csurUpdateInitialize import Initialize
from modules.computeNodeUpdate import ComputeNodeUpdate
from modules.updateReleaseInformation import updateVersionInformationFile


def main():
	#This is the location of the application.
	csurBasePath = '/hp/support/csur'

	initialize = Initialize()

	csurResourceDict = initialize.init(csurBasePath)

	print csurResourceDict
	exit(1)

	if csurResourceDict['systemType'] == 'Scale-up':
		computeNodeDict = csurResourceDict['componentUpdateDict']['computeNodeList'][0]
		systemModel = computeNodeDict['systemModel']

		#ComputeNode is the main class from which other classes have been subclassed due to minor variations in hardware.
		if (systemModel == 'DL580G7' or systemModel == 'DL980G7'):
			computeNode = Gen1ScaleUpComputeNode(computeNodeDict.copy(), csurResourceDict['noPMCFirmwareUpdateModels'], csurResourceDict['csurData'], csurResourceDict['fusionIOSoftwareInstallPackageList'])
		else:	
			computeNode = ComputeNode(computeNodeDict.copy(), csurResourceDict['noPMCFirmwareUpdateModels'], csurResourceDict['csurData'])

		'''
		****************************************************************************************************
		This section retrieves the list of components (firmware, drivers, software) that need to be updated.
		****************************************************************************************************
		'''
		print GREEN + "\nPhase 2: Retrieving a list of compute node components that need to be updated.\n" + RESETCOLORS

		try:
			computeNode.getComponentUpdateInventory()
		except KeyboardInterrupt:
			exit(1)

		if computeNode.getInventoryStatus():
			regex = r"^(y|n)$"
			print RED + "\n\n\tThere were errors while performing the system inventory." +  RESETCOLORS

			while True:
				response = raw_input("\n\tDo you want to continue at this time [y|n]: ")
				
				if not re.match(regex, response):
					print "A valid response is y|n.  Please try again."
					continue
				elif(response == 'n'):
					exit(1)
				else:
					break

		if (systemModel == 'DL580G7' or systemModel == 'DL980G7'):
			busList = computeNode.getFusionIOBusList()

			if len(busList) != 0:
				csurResourceDict['busList'] = busList

		componentUpdateDict = computeNode.getComponentUpdateDict()
		updateNeeded = False

		'''
		This gets a list of the dictionary sizes (Software, Drivers, Firmwware) so that 
		it can be determined whether or not an update is needed.
		'''
		componentDictSizes = [len(dict) for dict in componentUpdateDict.values()]

		if any(x != 0 for x in componentDictSizes):
			'''
			****************************************************************************************************
			This section updates the list of components (firmware, drivers, software) that need to be updated.
			****************************************************************************************************
			'''
			print GREEN + "\n\nPhase 3: Updating the compute node components that need to be updated." + RESETCOLORS
				
			#Instantiate the computeNode update class. We will be passing its main function (updateComputeNodeComponents) to a worker thread.
			computeNodeUpdate = ComputeNodeUpdate(computeNodeDict.copy(), componentUpdateDict.copy(), csurResourceDict.copy())

			#Get the current signal handlers so that they can be restored after the update is completed.
			original_sigint_handler = signal.getsignal(signal.SIGINT)
			original_sigquit_handler = signal.getsignal(signal.SIGQUIT)

			'''
			Setup signal handler to intercept SIGINT and SIGQUIT.
			Need to pass in a reference to the class object that will be peforming
			the update.  That way we gain access to the TimerThread so that it can be
			stopped/started.
			'''
			s = SignalHandler(computeNodeUpdate)

			signal.signal(signal.SIGINT, s.signal_handler)
			signal.signal(signal.SIGQUIT, s.signal_handler)

			#Create and start the worker thread.
			workerThread = Thread(target=computeNodeUpdate.updateComputeNodeComponents)
			workerThread.start()

			#Wait for the thread to either stop or get interrupted.
			while 1:
				time.sleep(0.1)

				if not workerThread.is_alive():
					break

				'''
				The response will be an empty string unless a signal was received.  If a signal is
				received then response is either 'n' (Don't cancel the update) or 'y' (Cancel the update.).
				'''
				response = s.getResponse()

				if response != '':
					if response == 'y':
						computeNodeUpdate.endTask()
						exit(1)

			#Restore the original signal handlers.
			signal.signal(signal.SIGINT, original_sigint_handler)
			signal.signal(signal.SIGQUIT, original_sigquit_handler)

			componentProblemDict = computeNodeUpdate.getUpdateComponentProblemDict()

			#Update the CSUR version information file.
			updateVersionInformationFileResult = updateVersionInformationFile(csurResourceDict.copy())

			#Move cursor down for formatting purposes.
			print '\n\n'

			if len(componentProblemDict['Software']) == 0 and len(componentProblemDict['Drivers']) == 0 and len(componentProblemDict['Firmware']) == 0:	
				if not updateVersionInformationFileResult:
					print YELLOW + 'The compute node update completed succesfully, however, the version information file update failed; check the log file for errors and update the file manually.\n' + RESETCOLORS
					print '\n' + PURPLE + 'Once the version information file is updated, reboot the system for the changes to take effect.\n' + RESETCOLORS
				else:
					print GREEN + 'The compute node update completed succesfully.\n' + RESETCOLORS
					print '\n' + PURPLE + 'Reboot the system for the changes to take effect.\n' + RESETCOLORS
			else:
				errorMessage = RED + 'The following components encountered errors during the update; check the log file for errors:\n'
				
				if len(componentProblemDict['Software']) != 0:
					errorMessage += UNDERLINE + "Software:" + RESETCOLORS + RED + ' ' + ', '.join(componentProblemDict['Software'].keys()) + '\n'

				if len(componentProblemDict['Drivers']) != 0:
					errorMessage += UNDERLINE + "Drivers:" + RESETCOLORS + RED + ' ' + ', '.join(componentProblemDict['Drivers'].keys()) + '\n'

				if len(componentProblemDict['Firmware']) != 0:
					errorMessage += UNDERLINE + "Firmware:" + RESETCOLORS + RED + ' ' + ', '.join(componentProblemDict['Firmware'].keys()) + '\n'

				if not updateVersionInformationFileResult:
					errorMessage += '\nAlso, the version information file update failed; check the log file for errors and update the file manually.\n'

				errorMessage += RESETCOLORS

				print errorMessage
		else:
			print GREEN + '\n\nThe compute node is already up to date; no action taken.\n' + RESETCOLORS
	else:
		pass

main()
