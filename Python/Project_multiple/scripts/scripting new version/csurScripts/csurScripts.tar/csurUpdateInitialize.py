import logging
import os
import subprocess
import re
import optparse
from csurUpdateUtils import (RED, GREEN, RESETCOLORS, TimeFeedbackThread)
from fusionIOUtils import checkFusionIOFirmwareUpgradeSupport
from systemConfiguration import SystemConfiguration
from collectComponentInformation import GetComponentInformation


class Initialize():
	def __init__(self):
		self.csurResourceDict = {}

	#End __init__(self):


	'''
	This function prints the initial application header.
	'''
	def __printHeader(self):
		version = 'Version 1.0-0'
		versionLength = len(version)
		title = "SAP HANA CSUR Update Application"
		titleLength = len(title)
		author = "Bill Neumann - SAP HANA CoE"
		authorLength = len(author)
		copyright = '(c) Copyright 2016 Hewlett Packard Enterprise Development LP'
		copyrightLength = len(copyright)
		
		print "+" + "-"*78 + "+"
		print "|" + title + " "*(78-titleLength) + "|"
		print "|" + version + " "*(78-versionLength) + "|"
		print "|" + author + " "*(78-authorLength) + "|"
		print "|" + copyright + " "*(78-copyrightLength) + "|"
		print "+" + "-"*78 + "+"
		print "\n"

	#End __printHeader(self):

	
	'''
	This is the main function that is called to do the program initialization for the 
	different components based on the users selection.
	'''
	def init(self, csurBasePath):
		#Save the csur base path to the csur resource dict as it will be needed later.
		self.csurResourceDict['csurBasePath'] = csurBasePath

		if os.geteuid() != 0:
			print RED + "You must be root to run this program; exiting program execution.\n" + RESETCOLORS
			exit(1)

		usage = 'usage: %prog [[-d] [-h] [-v]]'

		parser = optparse.OptionParser(usage=usage)

		parser.add_option('-d', action='store_true', default=False, help='This option is used when problems are encountered and additional debug information is needed.')
		parser.add_option('-v', action='store_true', default=False, help='This option is used to display the application\'s version.')

		(options, args) = parser.parse_args()

		self.__printHeader()

		print GREEN + "Phase 1: Initializing for the system update.\n" + RESETCOLORS 

	        systemConfiguration = SystemConfiguration()
        	systemConfigurationDict = systemConfiguration.getConfiguration()

		self.csurResourceDict.update(systemConfigurationDict)

		'''
		These are the resource files used by the application.  The csurAppResourceFile
		contains information specific to the application and CSUR, e.g. supported OS, etc.
		The csurDataResourceFile contains references to the objects being updated and the
		new version/package information.
		'''
		csurAppResourceFile = csurBasePath + '/resourceFiles/csurAppResourceFile'
		csurDataResourceFile = csurBasePath + '/resourceFiles/csurDataResourceFile'

		#Get csur application's resource file data and save it to a dictionary (hash).
		try:
			with open(csurAppResourceFile) as f:
				for line in f:
					line = line.strip()
					#Remove quotes from resources.
					line = re.sub('[\'"]', '', line)

					#Ignore commented and blank lines.
					if len(line) == 0 or re.match("^#", line):
						continue
					else:
						(key, val) = line.split('=')
						key = re.sub('\s+', '', key)
						self.csurResourceDict[key] = val.lstrip()
		except IOError as err:
			print RED + "\nUnable to open the application's resource file (" + csurAppResourceFile + ") for reading; exiting program execution.\n" + str(err) + "\n" + RESETCOLORS
			exit(1)

		#Get the csur's resource data (software, firmware, drivers) and save it to a list (array). 
		try:
			with open(csurDataResourceFile) as f:
				csurData = f.read().splitlines()
		except IOError as err:
			print RED + "\nUnable to open the CSUR's resource file (" + csurDataResourceFile + ") for reading; exiting program execution.\n" + str(err) + "\n" + RESETCOLORS
			exit(1)

		self.csurResourceDict['csurData'] = csurData

		logBaseDir = csurBasePath + '/log/'
		self.csurResourceDict['logBaseDir'] = logBaseDir

		try:
			mainApplicationLog = self.csurResourceDict['mainApplicationLog']
		except KeyError as err:
			print RED + "\nThe resource key (" + str(err) + ") was not present in the application's resource file " + csurAppResourceFile + "; exiting program execution.\n" + RESETCOLORS
			exit(1)

		mainApplicationLog = logBaseDir + mainApplicationLog

		try:
			#Always start with an empty log directory when performing a new update.
			logList = os.listdir(logBaseDir)

			for log in logList:
				os.remove(logBaseDir + log)
		except OSError as err:
			print RED + "\nUnable to remove old logs in " + logBaseDir + "; exiting program execution.\n" + str(err) + "\n" + RESETCOLORS
			exit(1)

		#Configure logging
		mainApplicationHandler = logging.FileHandler(mainApplicationLog)

		logger = logging.getLogger('mainApplicationLogger')

		'''
		The log level is saved to the csurResourceDict so that it can be referenced in other modules
		so that they set logging to the same level for their log files.
		'''	
		if options.d:
			logger.setLevel(logging.DEBUG)
			self.csurResourceDict['logLevel'] = 'debug'
		else:
			logger.setLevel(logging.INFO)
			self.csurResourceDict['logLevel'] = 'info'

		formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(message)s', datefmt='%m/%d/%Y %H:%M:%S')
		mainApplicationHandler.setFormatter(formatter)
		logger.addHandler(mainApplicationHandler)

		#************************************************
		#Remove after testing.
		#************************************************

		getComponentInformation = GetComponentInformation(self.csurResourceDict)
		componentListDict = getComponentInformation.getComponentInformation()

		self.csurResourceDict['componentListDict'] = componentListDict
		return self.csurResourceDict
#****************

                timeFeedbackThread = TimeFeedbackThread(componentMessage="\tCollecting system information")

		#This list holds the computeNode dictionaries.  There is only one compute node for a Scale-up.
		computeNodeList = []

		#This is a dictionary holding the system component data whether the system is a Scale-up or Scale-out.
		componentUpdateDict = {}

		try:
			if 'Scale-up' in systemConfigurationDict['systemType']:
				logger.info("The system type selected was a 'Scale-up'.") 
				timeFeedbackThread.daemon = True
				timeFeedbackThread.start()

				logger.info("Initializing for a Scale-up compute node update.") 
				computeNodeList.append(self.computeNodeInitialize())

				componentUpdateDict['computeNodeList']= computeNodeList
				self.csurResourceDict['componentUpdateDict'] = componentUpdateDict

				logger.info("Done initializing for a Scale-up compute node update.") 
			else:
				pass
		except KeyError as err:
                        logger.error("The resource key (" + str(err) + ") was not present in the resource file.")
			print RED + "\nA resource key error was encountered; check the log file for errors; exiting program execution.\n" + RESETCOLORS
			exit(1)

                timeFeedbackThread.stopTimer()
                timeFeedbackThread.join()

		return self.csurResourceDict

	#End init(self, csurBasePath):


	'''
	This function is used to initialize for a compute node update.
	'''
	def computeNodeInitialize(self): 
		try:
			logBaseDir = self.csurResourceDict['logBaseDir']
			logLevel = self.csurResourceDict['logLevel']
		except KeyError as err:
                        logger.error("The resource key (" + str(err) + ") was not present in the resource file.")
			print RED + "\nA resource key error was encountered; check the log file for errors; exiting program execution.\n" + RESETCOLORS
			exit(1)

		computeNodeDict = {}

		computeNodeLog = logBaseDir + '/computeNodeLog.log'
		computeNodeHandler = logging.FileHandler(computeNodeLog)

		#loggerName is set, since a reference to the logger is passed to checkDrivers().
		loggerName = 'computeNodeLogger'
		logger = logging.getLogger(loggerName)

		if logLevel == 'debug':
			logger.setLevel(logging.DEBUG)
		else:
			logger.setLevel(logging.INFO)

		formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(message)s', datefmt='%m/%d/%Y %H:%M:%S')
		computeNodeHandler.setFormatter(formatter)
		logger.addHandler(computeNodeHandler)

		#Check if SAP HANA is running.  We can assume that processes are not running is we get a return code of 1.
		command = 'ps -C hdbnameserver,hdbcompileserver,hdbindexserver,hdbpreprocessor,hdbxsengine,hdbwebdispatcher'
		result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
		out, err = result.communicate()

		logger.debug("The output of the command (" + command + ") used to check if SAP is running was: " + out.strip())

		if result.returncode == 0:
			logger.error("It appears that SAP HANA is still running.\n" + out)
			print RED + "\nIt appears that SAP HANA is still running; check the log file for errors; exiting program execution.\n" + RESETCOLORS
			exit(1)
		
		#Get the system's OS distribution version information.
		command = "cat /proc/version"
		result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
		out, err = result.communicate()

		logger.debug("The output of the command (" + command + ") used to get the OS distribution information was: " + out.strip())

		#Change version information to lowercase before checking for OS type.
		versionInfo = out.lower()
		
		if result.returncode != 0:
			logger.error("Unable to get the system's OS distribution version information.\n" + err)
			print RED + "\nUnable to get the system's OS distribution version information; check the log file for errors; exiting program execution.\n" + RESETCOLORS
			exit(1)

		if 'suse' in versionInfo:
			OSDist = 'SLES'
			command = "cat /etc/SuSE-release"
		else:
			OSDist = 'RHEL'
			command = "cat /etc/redhat-release"

		result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
		out, err = result.communicate()

		if result.returncode != 0:
			logger.error("Unable to get the system's OS distribution level.\n" + err)
			print RED + "\nUnable to get the system's OS distribution level; check the log file for errors; exiting program execution.\n" + RESETCOLORS
			exit(1)
		else:
			releaseInfo = out.replace('\n', ' ')

			if OSDist == 'SLES':
				slesVersion = re.match('.*version\s*=\s*([1-4]{2})', releaseInfo, re.IGNORECASE).group(1)
				slesPatchLevel = re.match('.*patchlevel\s*=\s*([1-4]{1})', releaseInfo, re.IGNORECASE).group(1)
				osDistLevel = OSDist + slesVersion + '.' + slesPatchLevel
			else:
				rhelVersion = re.match('.*release\s+([6-7]{1}.[0-9]{1}).*', releaseInfo, re.IGNORECASE).group(1)
				osDistLevel = OSDist + rhelVersion

		try:
			if osDistLevel not in self.csurResourceDict['supportedDistributionLevels']:
				logger.error("The system's OS distribution level (" + osDistLevel + ") is not supported by this CSUR bundle.")
				logger.info("The supported OS distribution levels are (" + self.csurResourceDict['supportedDistributionLevels'] + ").")
				print RED + "\nThe system's OS distribution level is not supported by this CSUR bundle; check the log file for errors; exiting program execution.\n" + RESETCOLORS
				exit(1)
		except KeyError as err:
                        logger.error("The resource key (" + str(err) + ") was not present in the resource file.")
			print RED + "\nA resource key error was encountered; check the log file for errors; exiting program execution.\n" + RESETCOLORS
			exit(1)

		computeNodeDict['osDistLevel'] = osDistLevel

		logger.debug("The system's OS distribution level was determined to be: " + osDistLevel + ".")

		#Get system model.
		command = "dmidecode -s system-product-name"
		result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
		out, err = result.communicate()

		logger.debug("The output of the command (" + command + ") used to get the system's model was: " + out.strip())

		if result.returncode != 0:
			logger.error("Unable to get the system's model information.\n" + err)
			print RED + "\nUnable to get the system's model information; check the log file for errors; exiting program execution.\n" + RESETCOLORS
			exit(1)
			
		systemModel = (re.match('[a-z,0-9]+\s+(.*)', out, re.IGNORECASE).group(1)).replace(' ', '')

		try:
			if systemModel not in self.csurResourceDict['supportedComputeNodeModels']:
				logger.error("The system's model (" + systemModel + ") is not supported by this CSUR bundle.")
				logger.info("The supported supported models are (" + self.csurResourceDict['supportedComputeNodeModels'] + ").")
				print RED + "\nThe system's model is not supported by this CSUR bundle; check the log file for errors; exiting program execution.\n" + RESETCOLORS
				exit(1)
		except KeyError as err:
                        logger.error("The resource key (" + str(err) + ") was not present in the resource file.")
			print RED + "\nA resource key error was encountered; check the log file for errors; exiting program execution.\n" + RESETCOLORS
			exit(1)

		logger.debug("The system's model was determined to be: " + systemModel + ".")

		computeNodeDict['systemModel'] = systemModel

		'''
		Additional kernel version and processorType is needed for FusionIO systems when the driver is rebuilt.	
		Also, need to confirm the system is already at a supported firmware version for automatic upgrades.
		'''
		if systemModel == 'DL580G7' or systemModel == 'DL980G7':
			#Check if /hana/log or /HANA/IMDB-log is mounted.
			command = 'mount'
			result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
			out, err = result.communicate()

			logger.debug("The output of the command (" + command + ") used to check if the log partition is mounted was: " + out.strip())

			if result.returncode != 0:
				logger.error("Unable to check if the log partition is mounted.\n" + err)
				print RED + "\nUnable to check if the log partition is mounted; check the log file for errors; exiting program execution.\n" + RESETCOLORS
				exit(1)

			if re.search('/hana/log|/HANA/IMDB-log', out, re.MULTILINE|re.DOTALL) != None:
				print RED + "\nThe log partition needs to be unmounted before the system is updated; exiting program execution.\n" + RESETCOLORS
				exit(1)

			#Get the currently used kernel and processor type, which is used as part of the FusionIO driver RPM name.
			command = 'uname -r'
			result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
			out, err = result.communicate()

			logger.debug("The output of the command (" + command + ") used to get the currently used kernel was: " + out.strip())

			if result.returncode != 0:
				logger.error("Unable to get the system's current kernel information.\n" + err)
				print RED + "\nUnable to get the system's current kernel information; check the log file for errors; exiting program execution.\n" + RESETCOLORS
				exit(1)
			else:
				kernel = out.strip()
				computeNodeDict['kernel'] = kernel
			
			command = 'uname -p'
			result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
			out, err = result.communicate()

			logger.debug("The output of the command (" + command + ") used to get the system's processor type was: " + out.strip())

			if result.returncode != 0:
				logger.error("Unable to get the system's processor type.\n" + err)
				print RED + "\nUnable to get the system's processor type; check the log file for errors; exiting program execution.\n" + RESETCOLORS
				exit(1)
			else:
				processorType = out.strip()
				computeNodeDict['processorType'] = processorType

			try:
				if not checkFusionIOFirmwareUpgradeSupport(self.csurResourceDict['fusionIOFirmwareVersionList']):
					print RED + "\nThe fusionIO firmware is not at a supported version for an automatic upgrade; check the log file for errors; exiting program execution.\n" + RESETCOLORS
					exit(1)
			except KeyError as err:
				logger.error("The resource key (" + str(err) + ") was not present in the resource file.")
				print RED + "\nA resource key error was encountered; check the log file for errors; exiting program execution.\n" + RESETCOLORS
				exit(1)

		#Confirm that the drivers for the system being updated are loaded.
		self.__checkDrivers(computeNodeDict.copy(), loggerName)

		return computeNodeDict

	#End computeNodeInitialize(self): 


	'''
	This function is used to confirm that the drivers to be checked for an update are loaded.
	'''
	def __checkDrivers(self, nodeDict, loggerName):
		csurData = self.csurResourceDict['csurData']
		osDistLevel = nodeDict['osDistLevel']
		systemModel = nodeDict['systemModel']

		logger = logging.getLogger(loggerName)

		driversFound = False
		started = False

		#Need to check twice for the Mellonex driver, since it can have two different names (mlx4_en or mlnx).
		mlnxDriverFound = False

                for data in csurData:
                        #Remove spaces if any are present.
                        data = data.replace(' ', '')

                        if not 'Drivers' in data and not driversFound:
                                continue
                        elif 'Drivers' in data:
                                driversFound = True
                                continue
                        elif not ((osDistLevel in data) and (systemModel in data)) and not started:
                                continue
                        elif (osDistLevel in data) and (systemModel in data):
                                started = True
                                continue
                        elif re.match(r'\s*$', data):
                                break
                        else:
                                csurDriverList = data.split('|')
                                csurDriver = csurDriverList[0]

                                command = "modinfo " + csurDriver
                                result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
                                out, err = result.communicate()

                                logger.debug("The output of the command (" + command + ") used to check if the " + csurDriver + " driver is loaded was: " + out.strip())

                                if result.returncode != 0:
					if (csurDriver == 'mlx4_en' or csurDriver == 'mlnx') and not mlnxDriverFound:
						mlnxDriverFound = True
						continue
					logger.error("The " + csurDriver + " driver does not appear to be loaded.\n" + err)
					print RED + "\nThe " + csurDriver + " driver does not appear to be loaded; check the log file for errors; exiting program execution.\n" + RESETCOLORS
					exit(1)

		if systemModel == 'DL580G7' or systemModel == 'DL980G7':
			command = "modinfo iomemory_vsl"
			result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
			out, err = result.communicate()

			logger.debug("The output of the command (" + command + ") used to check if the iomemory_vsl driver is loaded was: " + out.strip())

			if result.returncode != 0:
				logger.error("The iomemory_vsl driver does not appear to be loaded.\n" + err)
				print RED + "\nThe iomemory_vsl driver does not appear to be loaded; check the log file for errors; exiting program execution.\n" + RESETCOLORS
				exit(1)

	#End __checkDrivers(self, nodeDict, loggerName):

#End class Initialize():
