import subprocess
import logging
import re
import time
import os


'''
This class is used for updating the FusionIO driver and firmware subsystem 
on Gen1.0 Scale-up compute nodes.
'''
class FusionIOUpdate():
	def __init__(self):
		self.pid = 0
	#End __init__(self):


	'''
	This function is used to update the firmware of the FusionIO DIMMs.
	'''
	def updateFusionIOFirmware(self, busList, firmwareImage):
		updateStatus = True

		logger = logging.getLogger('computeNodeLogger')

		#Ensure self.pid is set to 0 before any work begins.
		self.pid = 0

		logger.info("Updating the FusionIO firmware.")

		'''
		Make sure to stop/unload the driver first if it is running.
		Will still try to continue if the check errors out.
		'''
		command = '/etc/init.d/iomemory-vsl status'
		result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, preexec_fn=os.setpgrp, shell=True)
		out, err = result.communicate()

		logger.debug("The output of the command (" + command + ") used to check if the FusionIO driver is running was: " + out.strip())

		if result.returncode != 0:
			logger.error("Problems were detected while checking if the FusionIO driver is running:\n" + err)

		if 'is running' in out:
			command = '/etc/init.d/iomemory-vsl stop'
			result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, preexec_fn=os.setpgrp, shell=True)
			out, err = result.communicate()

			logger.debug("The output of the command (" + command + ") used to stop the FusionIO driver from running was: " + out.strip())

			if result.returncode != 0:
				logger.error("Problems were detected while stopping the FusionIO driver from running:\n" + err)

		for bus in busList:
			time.sleep(2)
			
			command = "fio-update-iodrive -y -f -s " + bus + ' ' + firmwareImage
			result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, preexec_fn=os.setpgrp, shell=True)

			#We get the processes PID in case the process is cancelled and we need to kill the process.
			self.pid = result.pid

			out, err = result.communicate()

			logger.debug("The output of the command (" + command + ") used to update the FusionIO firmware was: " + out.strip())

			if result.returncode != 0:
				logger.error("Failed to upgrade the FusionIO firmware:\n" + err)
				updateStatus = False
				break

		return updateStatus

		logger.info("Done updating the FusionIO firmware.")

	#End updateFusionIOFirmware(self, busList, firmwareImage):


	'''
	This function is used to build and install the FusionIO driver.
	It also will install libvsl as well, since it had a dependency on the driver.
	'''
	def buildInstallFusionIODriver(self, csurResourceDict, driverDir):
		#updateStatus is the return variable as well as a control variable for what steps are performed.
		updateStatus = True

		#Ensure self.pid is set to 0 before any work begins.
		self.pid = 0

		logger = logging.getLogger('computeNodeLogger')
		logger.info("Building and installing the FusionIO driver.")
		
		try:
			computeNodeDict = csurResourceDict['componentUpdateDict']['computeNodeList'][0]
			fusionIODriverSrcRPM = csurResourceDict['fusionIODriverSrcRPM']
		except KeyError as err:
			logger.error("The resource key (" + str(err) + ") was not present in the resource file.")
			updateStatus = False

		if updateStatus:
			kernel = computeNodeDict['kernel']
			processorType = computeNodeDict['processorType']

			fusionIODriverSrcRPMPath = driverDir + "src/" + fusionIODriverSrcRPM

			#Build the driver for the new kernel.
			command = "rpmbuild --rebuild " + fusionIODriverSrcRPMPath
			result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, preexec_fn=os.setpgrp, shell=True)

			#We get the processes PID in case the process is cancelled and we need to kill the process.
			self.pid = result.pid

			out, err = result.communicate()

			logger.debug("The output of the command (" + command + ") used to build the FusionIO driver was: " + out.strip())

			if result.returncode != 0:
				logger.error("Failed to build the FusionIO driver:\n" + err)
				updateStatus = False

		if updateStatus:
			out = out.strip()

			'''
			This strips off iomemory from RPM name, since it will not be needed in the regex match.
			Additionally, the source RPM is renamed to the driver RPM's name, which includes the current 
			kernel and processor type in its name.
			'''
			fusionIODriverRPM = (fusionIODriverSrcRPM.replace('iomemory-vsl', '-vsl-' + kernel)).replace('src', processorType)

			#Compile the regex that will be used to get the driver RPM location.
			fusionIODriverPattern = re.compile('.*Wrote:\s+((/[0-9,a-z,A-Z,_]+)+' + fusionIODriverRPM +')', re.DOTALL)

			logger.debug("The regex used to get the FusionIO driver RPM location was: " + fusionIODriverPattern.pattern)

			driverRPM = re.match(fusionIODriverPattern, out).group(1)

			logger.debug("The FuionIO driver was determined to be: " + driverRPM)

			#Install the FusionIO software and driver.
			command = "rpm -ivh " + driverRPM + ' ' + driverDir + "libvsl-*.rpm"
			result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, preexec_fn=os.setpgrp, shell=True)

			#We get the processes PID in case the process is cancelled and we need to kill the process.
			self.pid = result.pid

			out, err = result.communicate()

			logger.debug("The output of the command (" + command + ") used to install the FusionIO driver was: " + out.strip())

			if result.returncode != 0:
				logger.error("Failed to install the FusionIO driver:\n" + err)
				updateStatus = False

		logger.info("Done building and installing the FusionIO driver.")

		return updateStatus

	#End buildInstallFusionIODriver(self, csurResourceDict, driverDir):


	'''
	This function is used to retrieve the PID of the currently running update.
	'''
	def getUpdatePID(self):
		return self.pid
	#End getUpdatePID(self):

#End class FusionIOUpdate():
