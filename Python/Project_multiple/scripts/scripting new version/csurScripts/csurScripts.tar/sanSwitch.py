#!/usr/bin/python


import pexpect
import re
import logging
import subprocess
from csurUpdateUtils import (InvalidPasswordError)


'''
This class is used for updating SAN switches.  
'''
class SANSwitch:
	def __init__(self, ip, password, serverIP, scpUsername, scpPassword, logBaseDir, logLevel):
                #Instance variables.
                self.ip = ip
                self.password = password
		self.serverIP = serverIP
		self.scpUsername = scpUsername
		self.scpPassword = scpPassword

		self.firmwareImage = None
		
                self.loggerName = ip + 'Logger'

                #Configure logging
                switchLog = logBaseDir + 'sanSwitch_' + ip + '.log'
                handler = logging.FileHandler(switchLog)

                logger = logging.getLogger(self.loggerName)

                if logLevel == 'debug':
                        logger.setLevel(logging.DEBUG)
                else:
                        logger.setLevel(logging.INFO)

                formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(message)s', datefmt='%m/%d/%Y %H:%M:%S')
                handler.setFormatter(formatter)
                logger.addHandler(handler)

	#End __init__(self, ip, password, serverIP, scpUsername, scpPassword, logBaseDir, logLevel):


	'''
	This function is used to check connectivity to the switch as well as checking 
	to see if the switch needs to be updated.
	'''
	def checkSwitch(self, sanSwitchResources, sanSwitchCrossReference):
		resultDict = {'updateNeeded' : False, 'errorType' : ''}
		prompt = re.compile('.*:admin>\s*')
		firmwareHeaderRegex = 'Appl\s+Primary/Secondary\s+Versions'

		sanSwitchCrossReferenceDict = dict(x.split('=') for x in re.sub('\s+=\s+', '=', re.sub(',\s*', ',', sanSwitchCrossReference)).split(','))

		logger = logging.getLogger(self.loggerName)

		logger.info("Checking the SAN switch's connnectivity, firmware version, and setting up ssh keys.")

		cmd = 'ssh -o PubkeyAuthentication=no -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no ' + 'admin@' + self.ip

		try:
			#We give 60 seconds to establish the connection.
			child = pexpect.spawn(cmd, timeout=60)

			child.expect('(?i)password:\s*')

			child.sendline(self.password)

			i = child.expect(['(?i)password:\s*', 'Please change passwords', prompt])
			
			if i == 0:
				logger.error("An invalid password was provided for admin.") 
				resultDict['errorMessage'] = 'An invalid password was provided for admin'
				raise InvalidPasswordError("An invalid password was provided for admin.") 

			if i == 1:
				child.sendcontrol('c')
				child.expect(prompt)

			#Get firmware information.
			child.sendline('firmwareshow')
			child.expect(prompt)
			firmwareInformation = child.before

			logger.debug("The output of the command (firmwareshow) used to check the switch's firmware version was: " + firmwareInformation)

			#Get switch type.
			child.sendline('switchshow')
			child.expect(prompt)
			switchInformation = child.before

			logger.debug("The output of the command (switchshow) used to check the switch's type was: " + firmwareInformation)

			'''
			Checking the switch's firmware version also confirms we are on a SAN switch, since a specific output is returned.
			'''
			if re.search(firmwareHeaderRegex, firmwareInformation, re.DOTALL|re.MULTILINE|re.IGNORECASE) == None:
				resultDict['errorMessage'] = "The component at '" + self.ip + "' is not a SAN switch."
				logger.error("The component at '" + self.ip + "' is not a SAN switch: " + firmwareInformation)
				logger.info("Done checking the SAN switch's connnectivity, firmware version, and setting up ssh keys.")
				return resultDict

			try:
				installedFirmwareVersion = re.search('(v(\d\.){2}\d[a-z]{1})', firmwareInformation).group(1)
				logger.debug("The switch's current firmware version was determined to be: " + installedFirmwareVersion + ".")
			except AttributeError:
				resultDict['errorMessage'] = "Could not determine the switch's firmware version."
				logger.error("Could not determine the switch's firmware version: " + firmwareInformation)
				logger.info("Done checking the SAN switch's connnectivity, firmware version, and setting up ssh keys.")
				return resultDict

			try:
				switchType = re.search('switchType:\s+(\d+)\.\d+', switchInformation).group(1)

				try:
					switchModel = sanSwitchCrossReferenceDict[switchType]
					logger.debug("The switch's model was determined to be: " + switchModel + ".")
				except KeyError as err:
					resultDict['errorMessage'] = "A resource key error was encountered."
					logger.error("The resource key (" + str(err) + ") was not present in the application's resource file.")
					logger.info("Done checking the SAN switch's connnectivity, firmware version, and setting up ssh keys.")
					return resultDict
			except AttributeError:
				resultDict['errorMessage'] = "Could not determine the switch's type."
				logger.error("Could not determine the switch's type: " + switchInformation)
				logger.info("Done checking the SAN switch's connnectivity, firmware version, and setting up ssh keys.")
				return resultDict

			switchResourceList = self.__getSwitchResources(switchModel, sanSwitchResources[:])

			if switchResourceList[0]:
				errorsEncountered = True
				resultDict['errorMessage'] = "An error occurred while getting the switch's resources."
				logger.info("Done checking the SAN switch's connnectivity, firmware version, and setting up ssh keys.")
				return resultDict

			switchResourceDict = switchResourceList[1]

			try:
				self.firmwareImage = switchResourceDict['firmwareImage']
				csurFirmwareVersion = switchResourceDict['firmwareVersion']

				if installedFirmwareVersion != csurFirmwareVersion:
					resultDict['updateNeeded'] = True
			except KeyError as err:
				resultDict['errorMessage'] = "A resource key error was encountered."
				logger.error("The resource key (" + str(err) + ") was not present in the resource file.")
				logger.info("Done checking the SAN switch's connnectivity, firmware version, and setting up ssh keys.")
				return resultDict

			#Set keys, since an update is required.  First delete any private keys so we start fresh.
			child.sendline('sshutil delprivkey')
			child.expect(prompt)
			child.sendline('sshutil genkey')
			child.expect('Enter passphrase.*:\s*')
			child.sendline('')
			child.expect('Enter same passphrase again:\s*')
			child.sendline('')
			child.expect(prompt)
			
			#Check for successfull build of new key.
			keyGenerationResult = child.before

			if 'generated successfully' not in keyGenerationResult:
				resultDict['errorMessage'] = 'Problems were encountered while generating a new key pair.'
				logger.error("Problems were encountered while generating a new key pair: " + keyGenerationResult)
				logger.info("Done checking the SAN switch's connnectivity, firmware version, and setting up ssh keys.")
				return resultDict

			child.sendline('sshutil exportpubkey')
			child.expect('Enter IP address:\s*')
			child.sendline(self.serverIP)
			child.expect('Enter remote directory:\s*')
			child.sendline('/tmp')
			child.expect('Enter login name:\s*')
			child.sendline(self.scpUsername)
			child.expect('password:\s*')
			child.sendline(self.scpPassword)
			child.expect(prompt)
			
			#Check for successfull export of public key.
			keyExportResult = child.before

			if 'is exported successfully' not in keyExportResult:
				resultDict['errorMessage'] = "There was a problem exporting the SAN switch's public key."
				logger.error("There was a problem exporting the SAN switch's public key to this system (" + self.serverIP + ").")
			else:
				command = 'cat /tmp/out_going_Brocade6510.pub >> ~' + self.scpUsername + '/.ssh/authorized_keys'
				result = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
				out, err = result.communicate()

				logger.debug("The output of the command (" + command + ") used to update " + self.scpUsername + "'s authorized_keys file with the SAN switch's public key was: " + out.strip())

				if result.returncode != 0:
					resultDict['errorMessage'] = "There was a problem importing the SAN switch's public key."
					logger.error("There was a problem importing the SAN switch's public key into " + self.scpUsername +"'s authorized_keys file.\n" + err)

			child.sendline('quit')

		except (pexpect.TIMEOUT, pexpect.EOF, pexpect.ExceptionPexpect) as e:
			resultDict['errorMessage'] = 'The session with the switch was aborted.'
			logger.error("Problems were encountered while checking the switch; session aborted: " + str(e))
		except InvalidPasswordError as e:
			logger.error(e.message)

		logger.info("Done checking the SAN switch's connnectivity, firmware version, and setting up ssh keys.")

		return resultDict

	#End checkSwitch(self, sanSwitchResources, sanSwitchCrossReference):


	'''
	This function is used to get the switch's resources from its resource file data.
	'''
        def __getSwitchResources(self, switchModel, sanSwitchResources):
                errorsEncountered = False
                started = False
                switchResourceDict = {}

                logger = logging.getLogger(self.loggerName)

                logger.info("Getting the resources for switch model '" + switchModel + "'.")

                for data in sanSwitchResources:
                        data = data.strip()

                        if not re.match(switchModel, data) and not started:
                                continue
                        elif re.match(switchModel, data):
                                started = True
                                continue
                        elif re.match(r'\s*$', data):
                                break
                        else:
                                resourceList = [x.strip() for x in data.split('=')]

                                try:
                                        switchResourceDict[resourceList[0]] = resourceList[1]
                                except IndexError as err:
                                        errorsEncountered = True
                                        logger.error("An index out of range error occured for switch resource list: " + resourceList)

                #If this is true, then the switch's model was missing or incorrectly entered into the SAN switch resource file.
                if not started:
                        errorsEncountered = True
                        logger.error("The switch's model (" + switchModel + ") was not found in the SAN switch resource file.")

                logger.info("Done getting the resources for switch model '" + switchModel + "'.")

                return [errorsEncountered, switchResourceDict]

        #End __getSwitchResources(self, switchModel, sanSwitchResources):


#This section is for running the module standalone for debugging purposes.
if __name__ == '__main__':
        ip = '10.41.0.10'
        serverIP = '10.41.0.15'
	scpUsername = 'root'
	scpPassword = 'x3r7ds5Q'
        password = 'password'
	switchSoftwareVersion = 'v7.2.2d'

	sanSwitch = SANSwitch(ip, password, serverIP, scpUsername, scpPassword)

	resultDict = sanSwitch.checkSwitch(switchSoftwareVersion)
	print resultDict
