#!/usr/bin/python


from csurUpdateUtils import (RED, RESETCOLORS)
import re

class SystemConfiguration:
        '''
        This function prompts the user for the type of update that is to be performed.
        '''
        def getConfiguration(self):
		systemConfigurationDict = {}

                while(1):
			startOver = False

			print ''
                        print "Select the system type to be updated:"
                        print "\t1. Scale-up"
                        print "\t2. Scale-out"

                        selection = raw_input()
                        selection = selection.strip()

                        if selection == '1':
				while 1:
                                        print "\nSelect the Scale-up configuration to be updated or enter 'q' to quit or 'x' to start over:"
                                        print "\t1. CS500 Scale-up\n\t2. CS900 Scale-up\n\t3. Gen1.0 Scale-up"
                                        selection = raw_input()

                                        selection = selection.strip().lower()

                                        if selection == '1':
                                                scaleUpType = 'CS500'
                                        elif selection == '2':
						print RED + "\nThe CS900 Scale-up is not supported at this time; please try again." + RESETCOLORS
						continue
                                                scaleUpType = 'CS900'
                                        elif selection == '3':
						print RED + "\nThe Gen1.0 Scale-up is not supported at this time; please try again." + RESETCOLORS
						continue
                                                scaleUpType = 'Gen1.0'
                                        elif selection == 'q':
                               			exit(0)
                                        elif selection == 'x':
                               			startOver = True                 
                                        else:
                                                print RED + "\nAn invalid selection was made; please try again." + RESETCOLORS
                                                continue

					if startOver:
						break

					if self.__confirmSelection({'Scale-up' : scaleUpType}):
						systemConfigurationDict['systemType'] = {'Scale-up' : scaleUpType}
						break
					else:
                               			startOver = True                 
						break

				if startOver:
					continue
                        elif selection == '2':
                                while 1:
					reselect = False

                                        print "\nSelect the Scale-out configuration to be updated or enter 'q' to quit or 'x' to start over:"
                                        print "\t1. CS500 Scale-out\n\t2. CS900 Scale-out\n\t3. Gen1.0 Scale-out\n\t4. Gen1.2 Scale-out"
                                        selection = raw_input()

                                        selection = selection.strip().lower()

                                        if selection == '1':
                                                scaleOutType = 'CS500'

						while 1:
							print "\nSelect the CS500 configuration to be updated or 'r' to reselect the Scale-out configuration:"
							print "\t1. CS500 Ivy Bridge\n\t2. CS500 Haswell\n\t3. Broadwell"

							selection = raw_input()
							selection = selection.strip()

							if selection == '1' or selection == '2':
								if selection == '1':
									generation = 'Ivy Bridge'
								else:
									generation = 'Haswell'

								componentList = self.__getCS500ComponentList()
								if self.__confirmSelection({'Scale-out' : [scaleOutType, componentList]}):
									systemConfigurationDict['systemType'] = {'Scale-out' : {'scaleOutType' : 'CS500', 'generation' : generation, 'componentList' : componentList}}
									break
								else:
									startOver = True                 
									break
							elif selection == '3':
								print RED + "\nThe Broadwell Scale-out is not supported at this time; please try again." + RESETCOLORS
								continue
								generation = 'Haswell'
							elif selection == 'r':
								reselect = True
							else:
								print "An invalid selection was made; please try again."
								continue

							if reselect:
								break
                                        elif selection == '2':
						print RED + "\nThe CS900 Scale-out is not supported at this time; please try again." + RESETCOLORS
						continue
                                                scaleOutType = 'CS900'
                                        elif selection == '3':
						print RED + "\nThe Gen1.0 Scale-out is not supported at this time; please try again." + RESETCOLORS
						continue
                                                scaleOutType = 'Gen1.0'
                                        elif selection == '4':
						print RED + "\nThe Gen1.2 Scale-out is not supported at this time; please try again." + RESETCOLORS
						continue
                                                scaleOutType = 'Gen1.2'
                                        elif selection == 'q':
                               			exit(0)
                                        elif selection == 'x':
                               			startOver = True                 
                                        else:
                                                print RED + "\nAn invalid selection was made; please try again." + RESETCOLORS
                                                continue

					if reselect:
						continue
					else:
						break

				if startOver:
					continue
                        else:
                                print "An invalid selection was made; please try again."
                                continue

                        break

		return systemConfigurationDict

        #End getConfiguration():


	def __confirmSelection(self, selection):
		regex = r"^(y|n)$"
		validInput = False

		print "Is the following system update information correct [y|n]:"

		if 'Scale-up' in selection:
			print "\t" + selection['Scale-up'] + " " + 'Scale-up'
		else:
			ScaleOutList = selection['Scale-out']

			print "\t" + ScaleOutList[0] + " " + 'Scale-out:'
			print "\n\tComponents that have been selected to update:"

			for component in ScaleOutList[1]:
				print "\t\t" + component

		while 1:
			response = raw_input()
			response = response.lower()

			if not re.match(regex, response):
				print RED + "\tA valid response is y|n.  Please try again." + RESETCOLORS
				continue

			if response == 'y':
				validInput = True

			break

		return validInput

	#End __confirmInput(self, selection):


	def __getCS500ComponentList(self):
		componentDict = {'1' : 'Compute Node', '2' : '3PAR StoreServ', '3' : 'SAN Switch', '4' : 'Network Switch'}
		componentList = []

		while 1:
			invalidResponse = False

			print "\nEnter a comma separated list of the Components to be updated or just press enter for everything:"
			print "\t1. ComputeNodes\n\t2. 3PAR StoreServ\n\t3. SAN Switches\n\t4. Network Switches"
			selection = raw_input("")
			selection = selection.strip()

			if ',' in selection:
				selection = re.sub('\s+', '', selection)
				componentSelectionList = selection.split(',')
				componentSelectionList.sort()

				for selection in componentSelectionList:
					try:
						selection = int(selection)
					except ValueError:
						print RED + "An invalid response was provided, please try again." + RESETCOLORS
						invalidResponse = True
						break

					if selection < 1 or selection > 4:
						print RED + "An invalid response was provided, please try again." + RESETCOLORS
						invalidResponse = True
						break

				if not invalidResponse:
					for selection in componentSelectionList:
						componentList.append(componentDict[selection])
			else:
				if len(selection) == 0:
					componentList = ['Compute Node', '3PAR StoreServ', 'SAN Switch', 'Network Switch']
				else:
					try:
						var = int(selection)
					except ValueError:
						print RED + "An invalid response was provided, please try again." + RESETCOLORS
						invalidResponse = True
						break

					if var < 1 or var > 4:
						print RED + "An invalid response was provided, please try again." + RESETCOLORS
						invalidResponse = True
					else:
						componentList.append(componentDict[selection])

			if not invalidResponse:
				break

		return componentList

	#End __getCS500ComponentList(self):

	
#This section is for running the module standalone for debugging purposes.
if __name__ == '__main__':
	systemConfiguration = SystemConfiguration()

	dict = systemConfiguration.getConfiguration()

	print dict
