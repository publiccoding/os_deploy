#!/usr/bin/python


import pexpect
import re
import logging
import subprocess
from csurUpdateUtils import (RED, RESETCOLORS, InvalidPasswordError, InUseError)


'''
This class is used for updating 3PAR Service Processor and StoreServ.  
**************Update to use resource dict, e.g. for log directory.
'''
class ThreePAR:
	def __init__(self, ip, user, password):
		self.ip = ip
		self.user = user
		self.password = password

                #Configure logging
		#******************Change this to use the resourceDict
		self.threePARLog = 'threePAR_' + ip + '.log'
                self.handler = logging.FileHandler(self.threePARLog)

		self.loggerName = ip + 'Logger'
                self.logger = logging.getLogger(self.loggerName)

		#******************Change this to use the resourceDict
		self.logger.setLevel(logging.DEBUG)

                self.formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(message)s', datefmt='%m/%d/%Y %H:%M:%S')
                self.handler.setFormatter(self.formatter)
                self.logger.addHandler(self.handler)



	'''
	This function is used to check connectivity to the 3PAR Service Processor as well
	as checking to see if the StoreServ needs to be updated.
	The 3parcust user can be used for checking 3PAR, but not for the update.
	'''
	def check3PAR(self, spVersion, storeServVersion):
		self.spVersion = spVersion
		self.storeServVersion = storeServVersion

		resultDict = {'errorType': '', 'storeServUpdateNeeded': True, 'spUpdateNeeded': True}

		self.logger.info("Checking the Service Processor's connnectivity and both its and the StoreServ's software version.")

		cmd = 'ssh -o PubkeyAuthentication=no -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no ' + self.user + '@' + self.ip

		try:
			#We give 60 seconds to establish the connection.
			child = pexpect.spawn(cmd, timeout=60)

			child.expect('(?i)password:\s*')

			child.sendline(self.password)

			i = child.expect(['(?i)password:\s*', 'Another copy of spmaint is already running', 'X\s+Exit'])
			
			if i == 0:
				resultDict['errorType'] = 'invalidPassword'
				raise InvalidPasswordError("An invalid password was provided for admin.") 

			if i == 1:
				resultDict['errorType'] = 'alreadyInUse'
				raise InUseError("Another copy of spmaint is already running.") 

			#First check the Service Processor's software version.
			child.sendline('1')
			child.expect('X\s+Return to previous menu')
			child.sendline('1')
			child.expect('Press <enter/return> to continue')
			versionInformation = child.before

			self.logger.debug("The output of the Service Processor's menu selection '1  ==>  Display SP Version' was: " + versionInformation)

			versionInformationList = versionInformation.splitlines()

			for line in versionInformationList:
				line = line.strip()

				if re.match('SP Version:\s+((\d\.){2}\d{1})', line) != None:
					softwareVersion = re.match('SP Version:\s+((\d\.){2}\d{1})', line).group(1)
					self.logger.debug("The Service Processor's current software version was determined to be: " + softwareVersion + ".")

					if softwareVersion != self.spVersion:
						resultDict['spUpdateNeeded'] = True

			#Now check the StoreServ's software version.
			child.sendline('')
			child.expect('X\s+Return to previous menu')
			child.sendline('x')
			child.expect('X\s+Exit')
			child.sendline('3')
			child.expect('X\s+Return to the previous menu')
			child.sendline('1')
			child.expect('Please select a StoreServ to operate on')
			child.sendline('1')
			child.expect('Press <enter/return> to continue')
			versionInformation = child.before
			child.sendline('')
			child.expect('X\s+Return to the previous menu')
			child.sendline('x')
			child.expect('X\s+Exit')
			child.sendline('x')

			self.logger.debug("The output of the Service Processor's menu selection '1  ==>  Display StoreServ information' was: " + versionInformation)

			versionInformationList = versionInformation.splitlines()

			for line in versionInformationList:
				line = line.strip()

				if re.match('\s*InForm OS Level:\s+(3.*)', line) != None:
					softwareVersion = re.match('\s*InForm OS Level:\s+(3.*)', line).group(1).strip()
					self.logger.debug("The StoreServ's current software version was determined to be: " + softwareVersion + ".")

					if softwareVersion != self.storeServVersion:
						resultDict['storeServUpdateNeeded'] = True

		except (pexpect.TIMEOUT, pexpect.EOF, pexpect.ExceptionPexpect) as e:
			resultDict['errorType'] = 'sessionAborted'
			self.logger.error("Problems were encountered while checking the 3PAR Service Processor and StoreServ; session aborted: " + str(e))
		except InvalidPasswordError as e:
			self.logger.error(e.message)
		except InUseError as e:
			self.logger.error(e.message)

		self.logger.info("Done checking the Service Processor's connnectivity and both its and the StoreServ's software version.")

		return resultDict

#This section is for running the module standalone for debugging purposes.
if __name__ == '__main__':
        ip = '10.41.0.28'
	user = 'spvar'
	password = '6swooNr'
	spVersion = '4.4.0'
	storeServVersion = '3.3.2'

	threePAR = ThreePAR(ip, user, password)

	resultDict = threePAR.check3PAR(spVersion, storeServVersion)
	print resultDict
