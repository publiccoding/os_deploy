#Colors available to use when printing messages to screen.
YELLOW = '\033[33m'
RED = '\033[31m'
GREEN = '\033[32m'
BLUE = '\033[34m'
PURPLE = '\033[35m'
BOLD = '\033[1m'
UNDERLINE = '\033[4m'
RESETCOLORS = '\033[0m'
