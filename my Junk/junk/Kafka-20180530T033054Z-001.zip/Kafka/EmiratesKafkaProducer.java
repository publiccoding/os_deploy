package com.emirates.sparkkafka.emirarteskafka;

import java.util.Properties;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class EmiratesKafkaProducer {

	Producer<String, String> prod;
	// org.apache.kafka.clients.producer.Producer producer = new
	// KafkaProducer<String, String>(configProperties);
	BufferedReader br = null;

	EmiratesKafkaProducer(String fileName, String topicName) {
		Properties prop = new Properties();
		prop.put("bootstrap.servers", "localhost:2181");
		prop.put("Serializer.class", "kafka.serializer.StringEncoder");
		prop.put("metadata.broker.list", "localhost:9092");
		prop.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		prop.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		// ProducerConfig proconfig = new ProducerConfig(prop);

		prod = new KafkaProducer(prop);
		FileReader fr = null;

		try {

			//fr = new FileReader(fileName);
			//br = new BufferedReader(fr);

			String sCurrentLine;

			br = new BufferedReader(new FileReader(fileName));

			while ((sCurrentLine = br.readLine()) != null) {
				ProducerRecord<String, String> rec = new ProducerRecord<String, String>(topicName, sCurrentLine);
				prod.send(rec);
			}

		} catch (IOException e) {

			e.printStackTrace();

		} finally {

			try {

				if (br != null)
					br.close();

				if (fr != null)
					fr.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}

		}

	}

	public static void main(String[] args) {
		if (args.length != 2) {
			System.err.println("Please specify 2 parameters ");
			System.exit(-1);
		}
		String FILENAME = args[0];
		String TOPICNAME = args[1];
		try{
			EmiratesKafkaProducer ekp = new EmiratesKafkaProducer(FILENAME, TOPICNAME);
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		
	}
}
