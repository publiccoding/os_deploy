Steps: Open Spark shell

spark-shell --packages org.apache.spark:spark-streaming-kafka-0-8_2.11:2.0.0,org.apache.kafka:kafka_2.11:0.10.2.1,org.apache.kafka:kafka-clients:0.10.2.1

import _root_.kafka.serializer.DefaultDecoder
import _root_.kafka.serializer.StringDecoder
import org.apache.spark.streaming.kafka.KafkaUtils
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming._


val ssc = new StreamingContext(sc, Seconds(5))   

val kafkaConf = Map(
    "metadata.broker.list" -> "10.128.0.2:9092",
    "zookeeper.connect" -> "10.128.0.2:2181",
    "group.id" -> "kafka-emirates",
    "zookeeper.connection.timeout.ms" -> "1000"
)

val lines1 = KafkaUtils.createStream[Array[Byte], String, DefaultDecoder, StringDecoder](
    ssc,
    kafkaConf,
    Map("Airports" -> 1),  
    StorageLevel.MEMORY_ONLY
)


val data = lines1.flatMap{case(x,y) => y.split("\n")}
data.print()
data.foreachRDD(rdd => rdd.saveAsTextFile("/data/raw/airports")) 
ssc.start()

